package day03homework.base;

import com.mchange.v2.c3p0.ComboPooledDataSource;

import java.beans.PropertyVetoException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

/**
 * 获取连接是从连接池获取，那么再获取连接之前，连接池必须先初始化
 * 连接池 -》 初始化几次 1次
 */
public class JdbcConnectionPoolUtil {

    private static ComboPooledDataSource comboPooledDataSource = null;

    private JdbcConnectionPoolUtil(){

    }

    private static JdbcConnectionPoolUtil jdbcConnectionPoolUtil = null;

    /**
     * 单例获取
     * @return
     */
    public  static JdbcConnectionPoolUtil getInstance(){
        if(null == jdbcConnectionPoolUtil){
            jdbcConnectionPoolUtil = new JdbcConnectionPoolUtil();
            initDatabaseConnectionPool();
        }
        return jdbcConnectionPoolUtil;
    }

    /**
     * 初始化连接池 只需要执行1次
     */
    public static void initDatabaseConnectionPool(){

        Properties properties = new Properties();
        String filePath = JdbcConnectionPoolUtil.class.getResource("/").getFile().toString() + "jdbc.properties";
        try {
            // 输入流
            InputStream is = new FileInputStream(filePath);
            properties.load(is);
        } catch (IOException e) {
            e.printStackTrace();
        }

        comboPooledDataSource = new ComboPooledDataSource();
        try {
            comboPooledDataSource.setDriverClass(properties.getProperty("driver"));
        } catch (PropertyVetoException e) {
            e.printStackTrace();
        }
        comboPooledDataSource.setJdbcUrl(properties.getProperty("url"));
        comboPooledDataSource.setUser(properties.getProperty("user"));
        comboPooledDataSource.setPassword(properties.getProperty("passwd"));
        comboPooledDataSource.setMinPoolSize(Integer.parseInt(properties.getProperty("c3p0.minPoolSize")));
        comboPooledDataSource.setMaxPoolSize(Integer.parseInt(properties.getProperty("c3p0.maxPoolSize")));
        comboPooledDataSource.setInitialPoolSize(Integer.parseInt(properties.getProperty("c3p0.initPoolSize")));
        comboPooledDataSource.setAcquireIncrement(Integer.parseInt(properties.getProperty("c3p0.acquireIncrement")));
    }

    public Connection getConnection(){
        if(null != comboPooledDataSource){
            try {
                return comboPooledDataSource.getConnection();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public void closeAll(ResultSet rs, Statement statement, Connection connection){
        closeResource(rs);
        closeResource(statement);
        // connection如果是连接池的连接，表示释放这个连接让其回到连接池
        closeResource(connection);
    }

    public void closeResource(AutoCloseable autoCloseable) {
        if (null != autoCloseable) {
            try {
                autoCloseable.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
