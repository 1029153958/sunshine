package day03homework.base;

import java.util.List;

/**
 * DAO data access object 数据访问项目
 */
public interface BaseDao {

    /**
     * 执行的查询操作
     *
     * @param sql     待执行的sql语句
     * @param clz     返回的list对象类型
     * @param objects sql的参数
     * @return 查询到的数据集合
     */
    List executeQuery(String sql, Class clz, Object... objects);

    /**
     * 执行的查询操作
     *
     * @param sql
     * @param clzPath Class.forName()，返回list对象类的全路径
     * @param objects
     * @return
     */
    List executeQuery(String sql, String clzPath, Object... objects);

    /**
     * 执行的增删改操作
     *
     * @param sql
     * @param objects
     * @return 返回受影响的行数
     */
    int executeUpdate(String sql, Object... objects);
}
