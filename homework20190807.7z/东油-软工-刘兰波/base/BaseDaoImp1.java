package day03homework.base;

import day02homework.JdbcUtil;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class BaseDaoImp1 implements BaseDao {

    @Override
    public List executeQuery(String sql, Class clz, Object... objects) {

        //获取连接
        Connection connection = JdbcUtil.getInstance().getConnection();
        //声明语句对象
        PreparedStatement preparedStatement = null;
        //结果集对象
        ResultSet resultSet = null;

        try {
            //通过连接语句对象执行sql
            preparedStatement = connection.prepareStatement(sql);

            System.out.println("BaseDaoImp1的executeQuery方法objects的长度"+objects.length);
            //objdects 可能有值，也可能没有值，由sql语句判断
            if (null != objects) {
                for (int i = 0; i < objects.length; i++) {
                    //参数设置，索引从1开始
                    preparedStatement.setObject(i + 1, objects[i]);
                }
            }

            //参数设置完毕，执行sql语句
            resultSet = preparedStatement.executeQuery();

            //返回一个集合对象
            return dealResultSet(resultSet, clz);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            JdbcUtil.getInstance().closeResourse(resultSet);
            JdbcUtil.getInstance().closeResourse(preparedStatement);
            JdbcUtil.getInstance().closeResourse(connection);
        }
        return null;
    }

    @Override
    public List executeQuery(String sql, String clzPath, Object... objects) {

        //获取连接
        Connection connection = JdbcUtil.getInstance().getConnection();
        //声明语句对象
        PreparedStatement preparedStatement = null;
        //结果集对象
        ResultSet resultSet = null;

        try {
            //通过连接语句对象执行sql
            preparedStatement = connection.prepareStatement(sql);

            //objdects 可能有值，也可能没有值，由sql语句判断
            if (null != objects) {
                for (int i = 0; i < objects.length; i++) {
                    //参数设置，索引从1开始
                    preparedStatement.setObject(i + 1, objects[i]);
                }
            }

            resultSet = preparedStatement.executeQuery();

            //根据clzPath得到clz 类的实例
            Class clz = Class.forName(clzPath);

            return dealResultSet(resultSet,clz);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public int executeUpdate(String sql, Object... objects) {

        // 获取连接
        Connection connection = JdbcConnectionPoolUtil.getInstance().getConnection();
        // 声明语句对象
        PreparedStatement preparedStatement = null;

        try {
            preparedStatement = connection.prepareStatement(sql);
            if (null != objects) {
                // i遍历从0开始
                for (int i = 0; i < objects.length; i++) {
                    // 参数设置，索引从1开始
                    preparedStatement.setObject(i + 1, objects[i]);
                }
            }

            return preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }


//    public List dealResultSet(ResultSet resultSet, Class clz) {
//
//        try {
//
//            // 表与实体类映射时，1.类的属性要与列名相同(第一种情况) 2.userOrder属性 对应的数据库列名为user-order（第二种情况）
//            // 通过反射获取clz所有的属性,如id，sname，ssex
//            Field[] fields = clz.getDeclaredFields();
//            // metadata-》元数据  获取ResultSet的元数据对象
//            ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
//            // 通过该元数据获取ResultSet中查询的数据一共有多少列
//            int columnCount = resultSetMetaData.getColumnCount();
//
//            List list = new ArrayList(16);
//
//            while (resultSet.next()) {
//                // 通过反射创建clz实例
//                Object object = clz.newInstance();
//                // 1	12	李四	男	123
//                for (int i = 0; i < columnCount; i++) {
//                    // 获取列的值
//                    Object columnValue = resultSet.getObject(i + 1);
//                    // 如果数据库中，这列没有值，则没有必要为其属性设置值
//                    if (null != columnValue) {
//                        // 获取列的名称  user_order
//                        String columnName = resultSetMetaData.getColumnName(i + 1).toLowerCase().replaceAll("_", "");
//                        for (int j = 0; j < fields.length; j++) {
//                            // 类的属性名  userOrder
//                            String name = fields[j].getName();
//                            // 判断类的属性名与列名是否相同
//                            if (name.toLowerCase().equals(columnName)) {
//                                // 列名与属性名相同，调用set方法将列值设置到对应的属性中
//                                // 根据名称，获取其set方法 name-》id  -》setId
//                                PropertyDescriptor pd = new PropertyDescriptor(name, clz);
//                                //获得写方法->即set方法，pd.getReadMethod();即get方法
//                                Method setMethod = pd.getWriteMethod();
//                                //  调用set方法设置值
//                                // 因为set方法中，参数的类型是确定的，不是Object，如setSname(String sname)，参数为String类型
//                                // 如果使用object类型传递进去，会报参数不匹配异常，所以此处需要对数据进行类型判断
//                                // 并根据不同的类型，进行转换
//                                // 获取属性的类型->获取类型的类名称，如String，Integer，Boolean
//                                String typeName = fields[j].getType().getSimpleName();
//                                if(typeName.equals("Integer")) {
//                                    // 隐含问题：1.如果数据库中声明为int unsigned-》columnValue通过java获取后是Long类型的
//                                    // 不带unsigned，是Integer类型
//                                    if( columnValue.getClass().getSimpleName().equals("Long")){
//                                        // 特殊情况。long的处理
//                                        setMethod.invoke(object, ((Long)columnValue).intValue());
//                                    } else {
//                                        setMethod.invoke(object, (Integer)columnValue);
//                                    }
//                                } else if (typeName.equals("String")){
//                                    // 如果数据库中是varchar类型，但是保存的是数值，获取到之后是Integer
//                                    // 所以这个地方使用toString进行转换，不管是什么类型，都会变成字符串
//                                    setMethod.invoke(object, columnValue.toString());
//                                } else if (typeName.equals("Date")){
//                                    // 自己写一个工具类，经columnValue转换为日期类型后设置进去
//                                    //setMethod.invoke(object, columnValue.toString());
//                                }// .....
//
//
//                                break;
//                            }
//                        }
//                    }
//                }
//                list.add(object);
//            }
//            // 程序运行正常，返回查询到的数据集合
//            return list;
//
//        } catch (InstantiationException e) {
//            e.printStackTrace();
//        } catch (IllegalAccessException e) {
//            e.printStackTrace();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        } catch (IntrospectionException e) {
//            e.printStackTrace();
//        } catch (InvocationTargetException e) {
//            e.printStackTrace();
//        }
//        return null;
//
//    }

    public List dealResultSet(ResultSet resultSet, Class clz) {
        try {
            // 表 与 实体类 映射时 1.类的属性要与类名相同  2.userOrder属性 对应的数据库列名位user_order
            // 通过反射，获取clz所有的属性
            Field[] fields = clz.getDeclaredFields();

            System.out.println("BaseDaoImp1的dealResultSet方法fields的长度"+fields.length);

            // metadata-> 元数据 获取ResultSet的元数据对象
            ResultSetMetaData resultSetMetaData = resultSet.getMetaData();

            // 通过该元数据获取ResultSet中查询的数据一共由多少列
            int columnCount = resultSetMetaData.getColumnCount();
            System.out.println("BaseDaoImp1的dealResultSet方法columnCount的长度"+columnCount);

            List list = new ArrayList(16);

            while (resultSet.next()) {

                //通过反射创建clz实例
                Object object = clz.newInstance();

                for (int i = 0; i < columnCount; i++) {
                    //获取列的值
                    Object columnValue = resultSet.getObject(i + 1);
                    //如果数据库中，这列没有值，则没有必要为其设置属性值
                    if (null != columnValue) {
                        //获取列的名称
                        String columnName = resultSetMetaData.getCatalogName(i + 1).toLowerCase().replace("_", "");
                        for (int j = 0; j < fields.length; j++) {
                            //类的属性名 userOrder
                            String name = fields[j].getName();

                            if (name.toLowerCase().equals(columnName)) {
                                //列名与属性名相同，调用set方法将列值对应的属性中
                                //根据名称，获取其set方法 name -> id -> setId
                                PropertyDescriptor propertyDescriptor = new PropertyDescriptor(name, clz);

                                //获得写方法-》即set方法，propertyDescriptor.getReadMethod()即get方法
                                Method setMethod = propertyDescriptor.getWriteMethod();

                                //调用set方法设置值
                                //因为再set方法中，参数的类型是确定的，不是Object
                                //如果使用Object类型传递进去，会报参数不匹配异常，所以此处需要对数据进行类型判断
                                //并根据不同的类型，进行转换
                                //获取类型的属性-》获取类型的类名称 如 String，Integer，Boolean

                                String typeName = fields[j].getType().getSimpleName();

                                if (typeName.equals("Integer")) {
                                    //隐含问题：如果数据库中声明为 int unsigned-> columnValue 通过 Java获取后是Long类型的
                                    //不带unsigned 是 Integer 类型的

                                    //此处进行特殊情况处理
                                    if (columnValue.getClass().getSimpleName().equals("Long")) {
                                        setMethod.invoke(object, ((Long) columnValue).intValue());
                                    } else {
                                        setMethod.invoke(object, ((Integer) columnValue));
                                    }
                                } else if (typeName.equals("String")) {
                                    setMethod.invoke(object, columnValue.toString());
                                } else if (typeName.equals("Date")) {
                                    // 自己写一个工具类，经 columnValue 转换为日期类型后设置进去
                                    //
                                }else{
                                    System.out.println("没有相匹配的类型");
                                }
                                break;
                            }
                        }
                    }
                }
                list.add(object);
            }
            return list;
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (IntrospectionException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        return null;
    }
}
