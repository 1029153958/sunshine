package day03homework.dao;

import day03homework.pojo.Course;

import java.util.List;

public interface CourseDao {
    /**
     * 查询所有课程
     * @return
     */
    List<Course> findAll();

    /**
     * 根据学号查询学生与其课程信息
     * @param cno
     * @return
     */
    List<Course> findCourseByCno(String cno);

}
