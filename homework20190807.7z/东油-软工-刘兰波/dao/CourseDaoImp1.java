package day03homework.dao;

import day03homework.base.BaseDaoImp1;
import day03homework.pojo.Course;

import java.util.List;

public class CourseDaoImp1 extends BaseDaoImp1 implements CourseDao {
    @Override
    public List<Course> findAll() {
        String sql = "select * from course";
        return executeQuery(sql,Course.class);
    }

    @Override
    public List<Course> findCourseByCno(String cno) {
        String sql = "select * from course where cno = ?";

        return executeQuery(sql,Course.class,cno);
    }
}
