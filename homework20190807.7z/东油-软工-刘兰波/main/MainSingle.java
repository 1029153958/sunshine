package day03homework.main;

import com.sun.corba.se.impl.resolver.FileResolverImpl;
import day03homework.dao.CourseDao;
import day03homework.dao.CourseDaoImp1;
import day03homework.pojo.Course;

import java.util.List;

public class MainSingle {
    public static void main(String[] args) {
        CourseDao courseDao = new CourseDaoImp1();
        List<Course> courseList = courseDao.findAll();
        //courseList.forEach(System.out::println);
        for (int i = 0; i < courseList.size(); i++) {
            System.out.println(courseList.get(i).toString());
        }
    }


}
